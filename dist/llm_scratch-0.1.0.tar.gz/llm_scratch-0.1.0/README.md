# LLM Deep Dive
Exploring LLMs by implementing and understanding all the key components, perform experiments and optimize it.
